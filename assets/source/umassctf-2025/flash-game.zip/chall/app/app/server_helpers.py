import os

ROLE_USER = 1
ROLE_DEV = 2
ROLE_ADMIN = 3
APP_SECRET = os.environ['APP_SECRET']