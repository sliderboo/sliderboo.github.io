CREATE DATABASE flashgamestudio;
\c flashgamestudio;

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE users (
    uid varchar(255)  UNIQUE NOT NULL,
    username varchar(255) PRIMARY KEY,
    password varchar(255) NOT NULL,
    user_desc text NOT NULL,
    role_id smallint NOT NULL
);

CREATE TABLE games (
    code text NOT NULL,
    game_name varchar(255) NOT NULL,
    game_desc varchar(255) NOT NULL,
    username varchar(255) REFERENCES users
);

INSERT INTO users VALUES(
    uuid_generate_v4(),
    'admin',
    'test',
    'i am the admin',
    3
);

INSERT INTO games VALUES(
    'UMASS{FLAG_FOR_TESTING}',
    'best game ever',
    'the best game ever',
    'admin'
);